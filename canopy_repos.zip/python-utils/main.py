from utils import greet, add_numbers

def main():
    print(greet('Kibi'))
    print('5 + 7 =', add_numbers(5, 7))

if __name__=='__main__':
    main()