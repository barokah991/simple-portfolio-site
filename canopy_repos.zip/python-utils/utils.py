def greet(name):
    return f'Hello, {name}! Welcome to the Python Utils repo.'

def add_numbers(a,b):
    return a+b