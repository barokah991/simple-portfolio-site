# Simple Portfolio Website
A clean and minimal personal portfolio website built using HTML, CSS, and JavaScript.